#!/bin/bash
# DraftProof - install the Word add-in (macOS).
# Copies the add-in manifest into Word's sideload folder.
set -e
WEF="$HOME/Library/Containers/com.microsoft.Word/Data/Documents/wef"
mkdir -p "$WEF"
echo "Downloading the DraftProof manifest..."
curl -fsSL https://draftproof.app/word-addin/manifest.xml -o "$WEF/draftproof.xml"
echo ""
echo "Installed. Restart Word, then open: Home > Add-ins > DraftProof."
echo "You can close this window."
